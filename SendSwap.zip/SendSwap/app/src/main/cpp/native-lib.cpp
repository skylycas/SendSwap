#include <jni.h>
#include <string>

using namespace std;

extern "C" JNIEXPORT jstring JNICALL
Java_com_yudo_sendswap_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

int newNum;
extern "C" JNIEXPORT jstring JNICALL
Java_com_yudo_sendswap_SignUpActivity_GetIdentitySeed(JNIEnv* env,jobject /* this */, jint num) {
    newNum = num + 1;
    return env->NewStringUTF(to_string(newNum).c_str());
}