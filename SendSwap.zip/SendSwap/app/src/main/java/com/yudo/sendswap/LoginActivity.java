package com.yudo.sendswap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private EditText loginEmail, password;
    private ProgressBar progressBar;
    private FirebaseAuth firebaseAuth;
    private TextView errorMessage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginEmail = findViewById(R.id.txtEmailAddressLogin);
        password = findViewById(R.id.txtPasswordLogin);
        progressBar = findViewById(R.id.pgBar);
        errorMessage = findViewById(R.id.txterr);
        errorMessage.setVisibility(View.INVISIBLE);

        firebaseAuth = FirebaseAuth.getInstance();
    }

    //-----------------------check if the user is a  registered users
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if(currentUser != null)
        {
            Intent redirect = new Intent(this, HomeActivity.class);
            startActivity(redirect);
            finish();
        }
    }

    public void linkSignup_Click(View view) {
        Intent redirect = new Intent(this, SignUpActivity.class);
        startActivity(redirect);
    }

    public void btnLoginthis_Click(View view) {
        String email = loginEmail.getText().toString();
        String pass = password.getText().toString();
        if(!TextUtils.isEmpty(email) || !TextUtils.isEmpty(pass))
        {
            progressBar.setVisibility(View.VISIBLE); //.........show progress bar
            firebaseAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful())
                    {
                        Intent redirect = new Intent(getApplicationContext(), HomeActivity.class);
                        startActivity(redirect);
                        finish();
                    }
                    else
                    {
                        progressBar.setVisibility(View.INVISIBLE); //.........remove progress bar
                        String msg = task.getException().getMessage();
                        errorMessage.setText("Login Failed: " + msg);
                        errorMessage.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
        else
        {
            errorMessage.setText("All fields are compulsory!");
            errorMessage.setVisibility(View.VISIBLE);
        }
    }

    public void linkForgotPass_Click(View view) {
    }

    public void imgHome_Click(View view) {
        Intent redirect = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(redirect);
    }
}