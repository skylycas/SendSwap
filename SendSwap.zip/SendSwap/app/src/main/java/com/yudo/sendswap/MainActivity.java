package com.yudo.sendswap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.yudo.sendswap.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'sendswap' library on application startup.
    static {
        System.loadLibrary("sendswap");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        // Example of a call to a native method
//        TextView tv = binding.sampleText;
//        tv.setText(stringFromJNI());
    }
    //-----------------------check if the user is a  registered users
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if(currentUser != null)
        {
            Intent redirect = new Intent(this, HomeActivity.class);
            startActivity(redirect);
            finish();
        }
    }
    /**
     * A native method that is implemented by the 'sendswap' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();

    public void btnSingUp_Click(View view) {
        Intent redirect = new Intent(this, SignUpActivity.class);
        startActivity(redirect);
    }

    public void btnLogin_Click(View view) {
        Intent redirect = new Intent(this, LoginActivity.class);
        startActivity(redirect);
    }
}