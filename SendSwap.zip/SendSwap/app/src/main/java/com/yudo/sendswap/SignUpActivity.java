package com.yudo.sendswap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignUpActivity extends AppCompatActivity{

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;
    private EditText fullname, nickname, emailaddress, phonenumber, password;
    private TextView countrycode, country, errorMessage;
    private Spinner spinnercountrycode, spinnercountry;
    UsersClass usersClass;
    int maximumid = 0;
    private ProgressBar progressBar;

    // Used to load the 'nativeclassapp' library on application startup.
    static {
        System.loadLibrary("sendswap");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        getSupportActionBar().hide();

        fullname = findViewById(R.id.txtFullName);
        nickname = findViewById(R.id.txtNickName);
        emailaddress = findViewById(R.id.txtEmailAddress);
        phonenumber = findViewById(R.id.txtPhoneNumber);
        password = findViewById(R.id.txtPassword);
        countrycode = findViewById(R.id.txtCountryCode);
        country = findViewById(R.id.txtcountry);

        errorMessage = findViewById(R.id.txterr);
        errorMessage.setVisibility(View.INVISIBLE);


        spinnercountrycode = findViewById(R.id.spinnercountrycode);
        spinnercountry =  findViewById(R.id.spinnerCountry);

        progressBar = findViewById(R.id.pgBar2);

        usersClass = new UsersClass();

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = firebaseDatabase.getInstance().getReference().child("tblUsers");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    maximumid = (int) snapshot.getChildrenCount();
                }
                else
                {
                    //
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        //----------------------Dropdown Implementation starts here
        ArrayAdapter<CharSequence> adaptercountrcode = ArrayAdapter.createFromResource(this, R.array.countrycode, android.R.layout.simple_spinner_item);
        adaptercountrcode.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercountrycode.setAdapter(adaptercountrcode);
        spinnercountrycode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String choice = parent.getItemAtPosition(position).toString();
                //Toast.makeText(getApplicationContext(), choice, Toast.LENGTH_SHORT).show();
                countrycode.setText(choice);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //Toast.makeText(getApplicationContext(), "Please select a Country Code", Toast.LENGTH_SHORT).show();
                countrycode.setText("null");
            }
        });

        ArrayAdapter<CharSequence> adaptercountries = ArrayAdapter.createFromResource(this, R.array.countries, android.R.layout.simple_spinner_item);
        adaptercountries.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercountry.setAdapter(adaptercountries);
        spinnercountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String choice = parent.getItemAtPosition(position).toString();
                //Toast.makeText(getApplicationContext(), choice + " country", Toast.LENGTH_SHORT).show();
                country.setText(choice);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //Toast.makeText(getApplicationContext(), "Please select a Country", Toast.LENGTH_SHORT).show();
                countrycode.setText("null");
            }
        });
        //----------------------Dropdown Implementation Ends here
    }


    public void linkLogin_Click(View view) {
        Intent redirect = new Intent(this, LoginActivity.class);
        startActivity(redirect);
    }

    public void btnSignUp_Click(View view) {
        usersClass.setFullname(fullname.getText().toString());
        usersClass.setNickname(nickname.getText().toString());
        usersClass.setEmail(emailaddress.getText().toString());
        usersClass.setPhonecode(countrycode.getText().toString());
        usersClass.setPhonenumber(phonenumber.getText().toString());
        usersClass.setPassword(password.getText().toString());
        usersClass.setCountry(country.getText().toString());


        //GetIdentitySeed(maximumid) adds one to the maximum identity seed gotten from DB using native c++

        databaseReference.child(String.valueOf(GetIdentitySeed(maximumid))).setValue(usersClass);

        //create email authentication for login
        firebaseAuth.createUserWithEmailAndPassword(usersClass.getEmail(),usersClass.getPassword()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Intent redirect = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(redirect);
                    finish();
                }
                else
                {
                    progressBar.setVisibility(View.INVISIBLE); //.........remove progress bar
                    String msg = task.getException().getMessage();
                    errorMessage.setText("Login Failed: " + msg);
                    errorMessage.setVisibility(View.VISIBLE);
                }
            }
        });

//        Toast.makeText(this, "Testing...", Toast.LENGTH_SHORT).show();
    }


    public void imgHome_Click(View view) {
        Intent redirect = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(redirect);
    }

    public native String GetIdentitySeed(int num);
}