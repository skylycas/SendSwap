package com.yudo.sendswap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class PaymentSetupActivity extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_setup);

        firebaseAuth = FirebaseAuth.getInstance();
    }

    public void btnReceiveAccount_Click(View view) {
    }

    public void btnSourceAccount_Click(View view) {
    }


    ///----------------Menu Bar for signout
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menulist, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //return super.onOptionsItemSelected(item);
        switch (item.getItemId())
        {
            case R.id.mnItem_Signout:
                firebaseAuth.signOut();
                Intent redirect = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(redirect);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}