package com.yudo.sendswap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity {

    private TextView txtMsg;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        firebaseAuth = FirebaseAuth.getInstance();
        txtMsg = findViewById(R.id.txtmessage);
    }

    //-----------------------check if the user is a  registered users
    @Override
    protected void onStart() {
        super.onStart();
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if(currentUser == null)
        {
            Intent redirect = new Intent(this, LoginActivity.class);
            startActivity(redirect);
            finish();
        }
        else
        {
            //check if at least one source account has been setup
            checkPaymentSource();
        }
    }

    private void checkPaymentSource()
    {
        String email = currentUser.getEmail();
        //txtMsg.setText(email);
        databaseReference = FirebaseDatabase.getInstance().getReference("tblPaymentSource");
        Query check = databaseReference.orderByChild("email").equalTo(email);
        check.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(!snapshot.exists())
                {
                    //you must setup a source account, so redirect to payment setup
                    Intent redirect = new Intent(getApplicationContext(), PaymentSetupActivity.class);
                    startActivity(redirect);
                }
                else
                {

//                    if(snapshot.getChildrenCount() == 3)
//                    {
//                        //create a session variable that will be used to disable the source button on the payment setup
//                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    //Create method to check receiving account and redirect accordingly




    ///----------------Menu Bar for signout
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menulist, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //return super.onOptionsItemSelected(item);
        switch (item.getItemId())
        {
            case R.id.mnItem_Signout:
                firebaseAuth.signOut();
                Intent redirect = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(redirect);
                return true;
            default:
               return super.onOptionsItemSelected(item);
        }
    }
}